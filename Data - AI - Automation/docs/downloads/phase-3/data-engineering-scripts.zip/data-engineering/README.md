# Data, AI & Automation Path — Phase 3A scripts (Data Engineering: storing and serving data)

Every script prints the same results you see in the lessons. The `data/` folder holds the 2025 practice data from Phase 2.

## Set up once

```bash
uv init --bare
uv add requests beautifulsoup4 pandas pyarrow "psycopg[binary]" duckdb sqlglot deltalake "pyiceberg[sql-sqlite,pyarrow]"
```

PostgreSQL (for scripts 03–10), easiest with Docker:

```bash
docker run --name pg -e POSTGRES_PASSWORD=practice -p 5432:5432 -d postgres:18
export DATABASE_URL=postgresql://postgres:practice@localhost:5432/postgres     # Windows PowerShell: $env:DATABASE_URL="..."
uv run 03_load_postgres.py
psql "$DATABASE_URL" -f 04_ctes.sql          # or paste the SQL into any client (DBeaver, pgAdmin, VS Code)
```

| Script | Module · lesson |
|---|---|
| `mock_api.py` | A local practice API + website. Start it first: `uv run mock_api.py` |
| `01_api_ingest.py` | Data ingestion · REST APIs, authentication and pagination |
| `02_scrape_formats.py` | Data ingestion · scraping; CSV vs JSON vs Parquet |
| `03_load_postgres.py` | Database engineering · loads `staging` and `shop` schemas |
| `04_ctes.sql`, `05_window_functions.sql` | Advanced SQL |
| `06_normalization.sql`, `07_indexing_explain.sql`, `08_transactions.py` | Database engineering |
| `09_star_schema.sql`, `10_scd.sql`, `11_bigquery_sql.py` | Data warehousing |
| `12_delta_medallion.py`, `13_iceberg_tables.py` | Lakehouse |
| `docker/` | Docker: `Dockerfile`, `Dockerfile.api`, `compose.yaml`, `ingest_job.py` |

Generated folders (`landing/`, `formats/`, `lake/`, `iceberg_warehouse/`, `docker/output/`) can be deleted at any time.
